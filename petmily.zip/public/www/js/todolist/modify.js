window.addEventListener("load", function () {
  const modifyButton = document.querySelector(
    ".todo-right-detail-right-modify",
  );

  modifyButton.addEventListener("click", () => {
    console.log("안녕");
  });
});
