import PetAdmin from "../components/calendar/PetAdmin";

const PetAdminPage = () => {
  return (
    <>
      <PetAdmin />
    </>
  );
};

export default PetAdminPage;
