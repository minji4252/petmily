import Index from "../components/calendar/Index";

const CalendarPage = () => {
  return (
    <div>
      <Index />
    </div>
  );
};

export default CalendarPage;
