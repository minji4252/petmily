import "../styles/main.css";
import "../styles/common.css";
import "../styles/reset.css";
import SlideMain from "./SlideMain";

const MainSlides = () => {
  return (
    <section className="main-sec-4">
      {/* <div className="main-bottom-slide"> */}
      <SlideMain />
      {/* </div> */}
    </section>
  );
};

export default MainSlides;
